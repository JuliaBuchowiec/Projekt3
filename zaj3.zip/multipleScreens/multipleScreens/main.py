from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.garden.mapview import MapView, MapMarker
import math

# Create both screens. Please note the root.manager.current: this is how
# you can control the ScreenManager from kv. Each screen has by default a
# property manager that gives you the instance of the ScreenManager used.
Builder.load_string("""
<MenuScreen>:
    BoxLayout:
        orientation: 'vertical'
        Button:
            text: 'Show me on the map'
            on_press: root.manager.current = 'showme'
        Button:
            text: 'Flags of world countries'
            on_press: root.manager.current = 'flags'

<ShowMeScreen>:
    search_lat: coor_lat
	search_long: coor_long
	my_map: map
	my_image: image
    scor: sc
    GridLayout:
        rows: 4
        cols: 1
        BoxLayout:
            size_hint_y: 1
            MapView:
                lat: 0
                lon: 0
                zoom: 1
                id: map
                on_map_relocated: root.draw_marker()
            Image:
                source: 'paris.jpg'
                id: image
        BoxLayout:
    		size_hint_y: 0.1
    		Label:
    			size_hint_x: 25
    			text: "Lat"
    		Label:
    			size_hint_x: 25
    			id: coor_lat
    		Label:
    			size_hint_x: 25
    			text: "Long"
    		Label:
    			size_hint_x: 25
    			id: coor_long
    	BoxLayout:
    		size_hint_y: 0.1
    		Label:
    			size_hint_x: 25
    			text: "Score"
    		Label:
    			size_hint_x: 25
    			text: '0'
                id: sc
    		Button:
    			size_hint_x: 25
    			text: "Check"
    			on_release: root.score()
    		Button:
    			size_hint_x: 25
    			text: "Next"
                on_release: root.switch()
        BoxLayout:
            size_hint_y: 0.1
            Button:
                height: "40dp"
                text: 'Back to menu'
                on_press: root.manager.current = 'menu'
            
<FlagsScreen>:
    BoxLayout:
        Label:
            text: 'Flags of world countries'
        Button:
            text: 'Back to menu'
            on_press: root.manager.current = 'menu'
""")

# Declare both screens
class MenuScreen(Screen):
    pass

#class ShowMeScreen(Screen):
#    def draw_marker(self):
#        
#        try:
#            self.my_map.remove_marker(self.marker)
#        except:
#            pass
#        
#        self.latitude = self.my_map.lat
#        self.longitude = self.my_map.lon
#        
#        self.marker = MapMarker(lat=self.latitude, lon=self.longitude)
#        self.my_map.add_marker(self.marker)
#        
#        self.search_lat.text = "{}".format(self.latitude)
#        self.search_long.text = "{}".format(self.longitude)
#        
#    def check_points(self):
#        print(list_of_points[0][0])
#        if self.my_image.source == list_of_points[0][0]:
#            print("wynik")
    
class ShowMeScreen(Screen):
    def draw_marker(self):        
        self.list_of_points=[["buckingham.jpg", 51.501476,-0.140634],
                             ["burjkhalifa.jpg", 25.1916159002, 55.2711322488],
                             ["campnou.jpg", 41.380898, 2.122820],
                             ["colloseum.jpg", 41.890251, 12.492373],
                             ["kualalumpur.jpg",3.157764,101.711861],
                             ["liberty.jpg", 40.689247,-74.044502], 
                             ["rondo.jpg", 52.232634,20.999496], 
                             ["stonehenge.jpg", 51.1740, -1.8224], 
                             ["tajmahal.jpg",27.1711659,78.038666],
                             ["whitehouse.jpg", 38.897957, -77.036560]]
        try:
            self.my_map.remove_marker(self.marker)
        except:
                pass
    
        self.latitude=self.my_map.lat
        self.longitude=self.my_map.lon
        
        self.marker=MapMarker(lat=self.latitude, lon=self.longitude)
        self.my_map.add_marker(self.marker)
        
        self.search_lat.text="{:.5f}".format(self.latitude)
        self.search_long.text="{:.5f}".format(self.longitude)
        self.i = 0
    
    def vincenty(self, lat1, lon1, lat2, lon2):
        e2=0.00669438002290;
        a=6378137;
        lambdaA=math.radians(lon1);
        lambdaB=math.radians(lon2);
        fiA=math.radians(lat1);
        fiB=math.radians(lat2);
        E=math.radians(0.000001/3600);
        b=a*math.sqrt(1-e2);
        f=1-(b/a);
        dL=lambdaB-lambdaA;
        Ua=math.atan((1-f)*math.tan(fiA));
        Ub=math.atan((1-f)*math.tan(fiB));
        L1=dL;
        L=0;
        while abs(L-L1)>E:
            L=L1;
            si=math.sqrt((math.cos(Ub)*math.sin(L1))**2+(math.cos(Ua)*math.sin(Ub)-math.sin(Ua)*math.cos(Ub)*math.cos(L1))**2);
            co=(math.sin(Ua)*math.sin(Ub))+(math.cos(Ua)*math.cos(Ub)*math.cos(L1)); 
            sigma=math.atan2(si,co);
            j=(math.cos(Ua)*math.cos(Ub)*math.sin(L1))/si; 
            k=1-j**2; 
            jk=co-((2*math.sin(Ua)*math.sin(Ub))/k); 
            C=(f/16)*k*(4+f*(4-3*k));
            L1=dL+(1-C)*f*j*(sigma+C*si*(jk+C*(co*(-1+2*(jk)**2))));
            
            u=((a**2-b**2)/b**2)*k;
            A=1+(u/16384)*(4096+u*(-768+u*(320-175*u)));
            B=(u/1024)*(256+u*(-128+u*(74-47*u)));
            dsigma=(B*si)*(jk+0.25*B*(co*(-1+2*(jk)**2)-(1/6)*B*jk*(-3+4*(si)**2)*(-3+4*(jk)**2)));
            sab=b*A*(sigma-dsigma);
        return sab
                
    def score(self):
        for k in range(0, len(self.list_of_points)):
            if self.my_image.source == self.list_of_points[k][0]:
                odl = self.vincenty(self.list_of_points[k][1], self.list_of_points[k][2],
                                    self.latitude, self.longitude)
                print(odl)
                if odl<1000000: #odleglosc w metrach
                    self.scor.text = "{}".format(int(self.scor.text) + 1)
                else:
                    pass
                
#    def score1(self):
#        if self.my_image.source1 == self.list_of_points[1][0]:
#            A=self.odleglosc.text.split(".")
#            print(A[0])
#            if float(A[0])<10000:
#                self.scor.text=str(1)
#            else:
#                self.scor.text=str(0)
#        

    def switch(self):
        if self.i >= len(self.list_of_points)-1:
            self.i = 0
        self.i += 1
        self.my_image.source = self.list_of_points[self.i][0]          


class FlagsScreen(Screen):
    pass

# Create the screen manager
sm = ScreenManager()
sm.add_widget(MenuScreen(name='menu'))
sm.add_widget(ShowMeScreen(name='showme'))
sm.add_widget(FlagsScreen(name='flags'))
#list_of_points = [
#                ['paris.jpg', 49, 3],
##                ['obrazek.jpg', 49, 45],
##                ['obrazek2.jpg', 49, 1]
#                ]

class multipleScreens(App):

    def build(self):
        return sm

if __name__ == '__main__':
    multipleScreens().run()